# Menu Creator
A personal project for creating, editing a viewing user created menus.
Tech stack: NodeJS, ReactJS, MySql.


prerequisite:
-------------
1. NodeJS installed.
2. MySql server installed
+ port: 3306, 
+ uid: "root"
+ psw: "root"


How to run
-----------
1. enter npm "install" to bring all required node_modules.
2. enter "npm start"
3. on the browser, surf to localhost:8080


Status
------
currently the client side react is not activited
